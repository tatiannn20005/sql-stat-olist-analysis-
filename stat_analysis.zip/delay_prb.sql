select c.customer_state,
count(*) as total_delivered, sum(o.order_delivered_customer_date>o.order_estimated_delivery_date) as delayed_orders, 
round(avg(o.order_delivered_customer_date >o.order_estimated_delivery_date)*100, 2) as delay_percentage
from orders o
join customers c using (customer_id)
where o.order_status = 'delivered'
group by c.customer_state
order by delay_percentage desc;
