
with monthly as (select DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m') as month,
count(distinct o.order_id) as orders,
SUM(oi.price) as sales from orders o
join order_items oi using (order_id)
group by month)
select m1.month, m1.orders, round(m1.sales, 2) as sales,
round((m1.sales - m2.sales)*100 / m2.sales,2) as grow_pct
from monthly m1
left join monthly m2 on str_to_date(concat(m1.month, '-01'), '%Y-%m-%d')
= date_add(str_to_date(concat(m2.month, '-01'), '%Y-%m-%d'), interval 1 month)
order by m1.month;