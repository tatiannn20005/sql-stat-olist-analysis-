use olist;
select date_format(order_purchase_timestamp, '%Y-%m') as month,
count(*) as trans_count,
sum(case when order_status = 'canceled' then 1 else 0 end) as approved_count,
sum(case when order_status = 'canceled' then 1 else 0 end)*100/count(*) as approved_total_amount
from orders
group by month;