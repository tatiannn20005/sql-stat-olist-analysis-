
with a as (select date_format(o.order_purchase_timestamp, '%Y-%m') as month,
o.order_id, sum(oi.price) as total from orders o
join order_items oi using (order_id)
group by month, o.order_id),
b as (select *, ROW_NUMBER() OVER (PARTITION BY month order by total) as bn,
count(*) over (partition by month) as n from a)
select month,avg(total) as avg_value,
avg(case when bn in (FLOOR((n+1)/2), FLOOR((n+2)/2))then total end) as median,
STDDEV_POP(total) as std from b
group by month
order by month;