with order_counts as (select order_id, COUNT(*) as n from order_items
group by order_id)
select least(n, 4) as items, count(*) as orders,
round(100 * count(*) / (select count(*) from order_counts), 2) as pt
from order_counts
group by least(n, 4)
order by items;
