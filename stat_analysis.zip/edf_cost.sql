with order_totals as (select order_id,
round(sum(price), 1) as order_value
from order_items
group by order_id)
select count(*) as total_orders,
round(AVG(order_value <= 50),2) as F_50,
round(AVG(order_value <= 100),2) as F_100,
round(AVG(order_value <= 200),2) as F_200
from order_totals;